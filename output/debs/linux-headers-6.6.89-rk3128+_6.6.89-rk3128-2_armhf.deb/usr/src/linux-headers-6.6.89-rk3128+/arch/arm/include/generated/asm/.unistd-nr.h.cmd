savedcmd_arch/arm/include/generated/asm/unistd-nr.h := sh /vol/kernel-src/arch/arm/tools/syscallnr.sh /vol/kernel-src/arch/arm/tools/syscall.tbl arch/arm/include/generated/asm/unistd-nr.h
