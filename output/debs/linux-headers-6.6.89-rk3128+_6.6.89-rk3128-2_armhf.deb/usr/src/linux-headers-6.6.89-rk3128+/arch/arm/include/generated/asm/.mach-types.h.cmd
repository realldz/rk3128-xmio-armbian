savedcmd_arch/arm/include/generated/asm/mach-types.h := awk -f /vol/kernel-src/arch/arm/tools/gen-mach-types /vol/kernel-src/arch/arm/tools/mach-types > arch/arm/include/generated/asm/mach-types.h
