savedcmd_arch/arm/include/generated/calls-oabi.S := sh /vol/kernel-src/scripts/syscalltbl.sh --abis common,oabi /vol/kernel-src/arch/arm/tools/syscall.tbl arch/arm/include/generated/calls-oabi.S
