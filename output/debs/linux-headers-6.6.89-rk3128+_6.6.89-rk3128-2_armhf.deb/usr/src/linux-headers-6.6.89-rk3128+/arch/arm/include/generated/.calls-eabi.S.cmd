savedcmd_arch/arm/include/generated/calls-eabi.S := sh /vol/kernel-src/scripts/syscalltbl.sh --abis common,eabi /vol/kernel-src/arch/arm/tools/syscall.tbl arch/arm/include/generated/calls-eabi.S
